
import Prelude hiding (reverse,concat,filter,map)

-- 1
reverse :: [a] -> [a]
reverse = foldr (\a as -> as ++ [a]) []

append :: [a] -> [a] -> [a]
append = flip $ foldr (:)

concat :: [[a]] -> [a]
concat = foldr append []

filter :: (a -> Bool) -> [a] -> [a]
filter p = foldr (\a as -> if p a then a:as else as) []

reverse' :: [a] -> [a]
reverse' = foldl (flip (:)) []

-- 2
data Polynom a = PN [a]
  deriving Show

evalPN :: Num a => Polynom a -> a -> a
evalPN (PN as) x = foldl (\r a -> r * x + a) 0 as

-- 3
type Vector = [Float]

add :: Vector -> Vector -> Vector
add = zipWith (+)

scale :: Float -> Vector -> Vector
scale s = map (s*)

dot :: Vector -> Vector -> Float
dot x y = sum $ zipWith (*) x y

-- 4
type Matrix = [Vector]

multMatVec :: Matrix -> Vector -> Vector
multMatVec m v = map (dot v) m

addColumn :: Vector -> Matrix -> Matrix
addColumn v [] = map (:[]) v
addColumn v m  = zipWith (:) v m

transpose :: Matrix -> Matrix
transpose = foldr addColumn []

multMatMat :: Matrix -> Matrix -> Matrix
multMatMat m1 m2 = map (multMatVec (transpose m2)) m1

multMatMat2 :: Matrix -> Matrix -> Matrix
multMatMat2 m1 m2 = transpose . map (multMatVec m1) $ transpose m2

addColumn2 :: Vector -> Matrix -> Matrix
addColumn2 = zipWith (:)

transpose2 :: Matrix -> Matrix
transpose2 m = foldr addColumn2 (replicate (columns m) []) m
  where
    columns :: Matrix -> Int
    columns []      =  0
    columns (c:cs)  =  length c

-- 5
map :: (a -> b) -> [a] -> [b]
map f as = [ f a | a <- as ]

filter' :: (a -> Bool) -> [a] -> [a]
filter' p as = [ a | a <- as, p a ]

concat' :: [[a]] -> [a]
concat' ass = [ a | as <- ass, a <- as ]

-- 6
lc1 :: (a -> b) -> (a -> Bool) -> [a] -> [b]
lc1 f p = map f . filter p

bind :: [a] -> (a -> [b]) -> [b]
bind m f = concat (map f m)

lc2 :: [a] -> (a -> [b]) -> (b -> Bool) -> [(a,b)]
lc2 as f p =
  bind as                $ \a ->
  bind (filter p (f a))  $ \b ->
    [(a,b)]
lc3 :: Int -> [(Int,Int,Int)]
lc3 n =
  bind (filter even [1..n])                     $ \a ->
  bind [a..n]                                   $ \b ->
  bind (filter (\c -> a^2 + b^2 == c^2) [b..n]) $ \c ->
    [(a,b,c)]

-- Simple (X)HTML markup.
data Attr = Attr String String
  deriving (Eq,Show)

data HtmlElement 
  = HtmlString String                    -- Plain text.
  | HtmlTag String [Attr] HtmlElements   -- Structured markup.
  deriving (Eq, Show)

type HtmlElements = [HtmlElement]

example :: HtmlElement
example =
  HtmlTag "a" [Attr "href" "http://www.ugent.be/"]
    [HtmlString "Universiteit Gent"]


-- HTML renderable class.
class HTML a where
  toHtml :: a -> HtmlElement

-- 7
data Link =  Link
               String  -- Link target.
               String  -- Text to show.
  deriving (Eq,Show)

instance HTML Link where
  toHtml (Link hrf txt) = HtmlTag "a" [Attr "href" hrf] [HtmlString txt]

-- 8
instance (HTML a, HTML b) => HTML (Either a b) where
  toHtml (Left a) = toHtml a
  toHtml (Right b) = toHtml b

-- 9
ul :: HtmlElements -> HtmlElement
ul = HtmlTag "ul" []

li :: HtmlElement -> HtmlElement
li e = HtmlTag "li" [] [e]

instance HTML a => HTML [a] where
  toHtml = ul . map (li . toHtml)

-- 10
data AddressBook = AddressBook
    String    -- Owner
    [Person]  -- Contacts
data Person = Person
    String    -- First name
    String    -- Last name
    String    -- Image
    [Email]   -- Email
    [Address] -- Address
  deriving (Eq,Show)
data Kind = Private | Work | Other
  deriving (Eq,Show)
data Email = Email Kind String
  deriving (Eq,Show)
data Address = Address
    Kind      -- Kind
    String    -- Street
    String    -- Code
    String    -- City
    String    -- Country
  deriving (Eq,Show)

myAddressBook :: AddressBook
myAddressBook =
  AddressBook "Steven"
  [ Person "Steven" "Keuchel"
      "http://m4.licdn.com/mpr/mpr/shrink_80_80/p/2/000/089/1c0/01fb6a2.jpg"
      [ Email Private "steven.keuchel@gmail.com",
        Email Work    "steven.keuchel@ugent.be"
      ]
      [ Address Work
          "Krijgslaan 281 S9"
          "9000"
          "Gent"
          "Belgium"
      ],
    Person "Tom" "Schrijvers"
      "http://users.ugent.be/~tschrijv/images/tombw.jpg"
      [ Email Work "tom.schrijvers@ugent.be" ]
      [ Address Work
          "Krijgslaan 281 S9"
          "9000"
          "Gent"
          "Belgium"
      ]
  ]


-- 11
-- HTML markup abbreviations.
br :: HtmlElement
br     =  HtmlTag "br" [] []

html, body, tr, td, h2, h3 :: HtmlElements -> HtmlElement
html   =  HtmlTag "html" []
body   =  HtmlTag "body" []
tr     =  HtmlTag "tr" []
td     =  HtmlTag "td" []
h2     =  HtmlTag "h2" []
h3     =  HtmlTag "h3" []

table :: [Attr] -> HtmlElements -> HtmlElement
table = HtmlTag "table"

border :: Int -> Attr
border = Attr "border" . show
width :: Int -> Attr
width = Attr "width"  . show

emptyRow :: HtmlElement
emptyRow = tr [ td [ br ] ]


instance HTML Kind where
  toHtml k = HtmlString $ show k

instance HTML Address where
  toHtml (Address kind street code city country) =
    tr [ td [ toHtml kind ],
         td [ HtmlString street , br,
              HtmlString (code ++ " " ++ city), br,
              HtmlString country]
       ]

instance HTML Email where
  toHtml (Email kind address) =
    tr [ td [ toHtml kind ],
         td [ toHtml (Link ("mailto:" ++ address) address) ]
       ]

instance HTML Person where
  toHtml (Person firstName lastName image emails addresses) =
    table [border 1, width 400] [ tr [ td [ innerTable ] ] ]
    where
      name :: HtmlElement
      name = h2 [ HtmlString (firstName ++ " " ++ lastName) ]
      img = HtmlTag "img" [Attr "src" image, width 80] []
      innerTable :: HtmlElement
      innerTable = table [] $
        [ tr [ td [ img ], td [ name] ],
          emptyRow,
          tr [ td [ h3 [ HtmlString "Email addresses:" ] ] ]
        ] ++
        map toHtml emails ++
        [ emptyRow,
          tr [ td [ h3 [ HtmlString "Addresses:" ] ] ]
        ] ++
        map toHtml addresses

instance HTML AddressBook where
  toHtml (AddressBook owner contacts) = html
    [ HtmlTag "head" [Attr "title" $ owner ++ "'s Address Book"] []
    , body $ map toHtml contacts
    ]


-- 11
renderAttribute :: Attr -> String
renderAttribute (Attr name value)
  = name ++ "=" ++ "\"" ++ value ++ "\""

renderElement :: HtmlElement -> String
renderElement (HtmlString s) = s
renderElement (HtmlTag t as c)
  = let
      as'   = map renderAttribute as
      start = "<" ++ unwords (t : as')
      end   = "</" ++ t ++ ">"
    in case c of
      [] -> start ++ " />"
      _  -> start ++ ">" ++ renderHtml c ++ end

renderHtml :: HtmlElements -> String
renderHtml = concatMap renderElement

render :: HTML a => a -> String
render = renderElement . toHtml

main :: IO ()
main =
  writeFile "AddressBook.html" (render myAddressBook)
